<?php

namespace App\Services;

class UserServices
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
