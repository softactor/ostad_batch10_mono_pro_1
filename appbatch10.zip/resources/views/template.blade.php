@extends('frontend.layout.app')

@section('title', 'Simpleshop-Home')


@section('content')


    <div class="container">
        
    </div>




@endsection