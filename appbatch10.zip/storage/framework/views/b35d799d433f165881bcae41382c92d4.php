
<?php $__env->startSection('title', 'About us'); ?>


<?php $__env->startSection('content'); ?>
    <h1><?php echo e($heading); ?></h1>


    <?php if($day == 'Sun'): ?>
        
        Today is Sunday
    
    <?php elseif($day == 'Mon'): ?> 
        Today is Monday

    <?php elseif($day == 'Tue'): ?> 

        Today is Tuesday

    <?php elseif($day == 'Wed'): ?> 

        Today is Wednesday

    <?php elseif($day == 'Thu'): ?> 

        Today is Thursday

    <?php elseif($day == 'Fri'): ?> 

        Today is Friday
        
    <?php else: ?> 

        Today is Holiday!

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\tanve\Herd\appbatch10\resources\views/about.blade.php ENDPATH**/ ?>