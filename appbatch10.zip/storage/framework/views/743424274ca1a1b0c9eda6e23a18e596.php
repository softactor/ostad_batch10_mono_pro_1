<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?php echo $__env->yieldContent('title', 'Simple Shop'); ?></title>

  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom CSS -->
  <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">

  <?php echo $__env->yieldContent('style'); ?>


</head>
<body>
  
    <!-- topnav -->

    <?php echo $__env->make('frontend.layout.topnav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


  <main class="py-4">
  
        <?php echo $__env->yieldContent('content'); ?>

  </main>

  <footer class="bg-light py-3">
    <div class="container text-center small">
      &copy; <?php echo e(date('Y')); ?> SimpleShop
    </div>
  </footer>

  <!-- Bootstrap bundle (Popper included) -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
  
  <?php echo $__env->yieldContent('script'); ?>



</body>
</html><?php /**PATH C:\Users\tanve\Herd\appbatch10\resources\views/frontend/layout/app.blade.php ENDPATH**/ ?>