

<?php $__env->startSection('title', 'Simpleshop-Home'); ?>


<?php $__env->startSection('content'); ?>


<div class="container">
      
        <!-- hero sectiion -->

        <?php echo $__env->make('frontend.partials.hero', ['title' => 'Welcome to SimpleShop', 'short_description' => 'A minimal Bootstrap e‑commerce starter — plain HTML files so you can demonstrate conversion to Blade or Vue later.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>       

      <div class="row mb-4">
        <div class="col-md-4">
          <h4>Fast Setup</h4>
          <p>Drop files into a folder and open index.html in the browser.</p>
        </div>
        <div class="col-md-4">
          <h4>Simple Design</h4>
          <p>Bootstrap 5 + tiny CSS so students can follow how pages are structured.</p>
        </div>
        <div class="col-md-4">
          <h4>Vue Ready</h4>
          <p>Pages are structured so you can later mount Vue components on the #app element.</p>
        </div>
      </div>

      <h3 class="mb-3">Featured Products</h3>
      <div class="row row-cols-1 row-cols-md-3 g-4">
        
        
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="col">
          <div class="card h-100">
            <img src="<?php echo e($product->product_image); ?>" class="card-img-top" alt="<?php echo e($product->title); ?>">
            <div class="card-body">
              <h5 class="card-title"><?php echo e($product->title); ?></h5>
              <p class="card-text"><?php echo e($product->short_description); ?></p>
            </div>
            <div class="card-footer d-flex justify-content-between">
              <strong><?php echo e($product->price); ?></strong>
              <a href="product_details.html" class="btn btn-sm btn-outline-primary">View</a>
            </div>
          </div>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
      </div>
    </div>




    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\tanve\Herd\appbatch10\resources\views/frontend/home.blade.php ENDPATH**/ ?>