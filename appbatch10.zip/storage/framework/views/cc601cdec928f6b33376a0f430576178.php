<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product</title>
</head>
<body>

    <h1>Product</h1>

    <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel maxime libero necessitatibus omnis velit voluptates error, ab voluptatem iste tenetur consequuntur. Iusto ipsa ut, sed nam voluptates officiis praesentium laboriosam, sapiente delectus quo cum numquam labore est, minus odio voluptate temporibus vero? Accusamus quasi ipsam exercitationem dignissimos incidunt voluptates delectus.
    </p>
    
</body>
</html><?php /**PATH C:\Users\tanve\Herd\appbatch10\resources\views/product.blade.php ENDPATH**/ ?>