<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
      <a class="navbar-brand" href="<?php echo e(url('/')); ?>">SimpleShop</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navMenu">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link active" href="<?php echo e(url('/')); ?>">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/about')); ?>">About</a></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/product')); ?>">Products</a></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/contact')); ?>">Contact</a></li>
        </ul>
      </div>
    </div>
  </nav><?php /**PATH C:\Users\tanve\Herd\appbatch10\resources\views/frontend/layout/topnav.blade.php ENDPATH**/ ?>