

<?php $__env->startSection('title', 'Simpleshop-Contact'); ?>


<?php $__env->startSection('content'); ?>


    <div class="container">
      <h1>Contact Us</h1>
      <p class="mb-4">Have a question? Send us a message and we'll get back to you.</p>

      <form id="contactForm" method="POST" action="#">
        <div class="mb-3">
          <label for="name" class="form-label">Name</label>
          <input id="name" name="name" class="form-control" required>
        </div>

        <div class="mb-3">
          <label for="email" class="form-label">Email</label>
          <input id="email" name="email" type="email" class="form-control" required>
        </div>

        <div class="mb-3">
          <label for="message" class="form-label">Message</label>
          <textarea id="message" name="message" rows="5" class="form-control" required></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Send Message</button>
      </form>
    </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\tanve\Herd\appbatch10\resources\views/frontend/contact.blade.php ENDPATH**/ ?>