<?php $__env->startSection('title', 'Home'); ?>


<?php $__env->startSection('content'); ?>
    <h1><?php echo e($heading); ?></h1>

    <div style="border: 1px solid black; margin: 5px; padding: 5px;">

        <?php echo $withHtml; ?>


    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\tanve\Herd\appbatch10\resources\views/welcome.blade.php ENDPATH**/ ?>