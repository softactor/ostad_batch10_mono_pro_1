<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>
</head>
<body>

    <h1>Hay Contact!</h1>

</body>
</html><?php /**PATH C:\Users\tanve\Herd\appbatch10\resources\views/contact/contact.blade.php ENDPATH**/ ?>