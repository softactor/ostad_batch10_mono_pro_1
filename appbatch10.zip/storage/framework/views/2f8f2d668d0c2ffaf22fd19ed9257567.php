<div class="p-5 mb-4 bg-light rounded-3">
    <h1 class="display-5 fw-bold"><?php echo e($title); ?></h1>
    <p class="col-md-8 fs-5"><?php echo e($short_description); ?></p>
    <a href="<?php echo e(url('/product')); ?>" class="btn btn-primary btn-lg">Shop Now</a>
</div><?php /**PATH C:\Users\tanve\Herd\appbatch10\resources\views/frontend/partials/hero.blade.php ENDPATH**/ ?>